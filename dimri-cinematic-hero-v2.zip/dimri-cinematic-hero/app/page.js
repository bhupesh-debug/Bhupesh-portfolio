import VideoIntro from '@/components/VideoIntro/VideoIntro'
import ProfileSection from '@/components/ProfileSection/ProfileSection'

export default function Home() {
  return (
    <main>
      <VideoIntro
        videoSrc="/videos/hero.mp4"
        resumeSrc="/resume/dimri-resume.pdf"
        firstName="Bhupesh"
        lastName="Dimri"
        roleSubtitle="Financial Analyst — FP&A & Financial Modeling"
        tagline="Portfolio / 2026"
        highlights={[
          { value: '27%', label: 'Forecast Accuracy ↑' },
          { value: '<2hrs', label: 'Reporting Latency' },
          { value: '$50M+', label: 'Budgets Managed' },
        ]}
      />
      <ProfileSection />
    </main>
  )
}
