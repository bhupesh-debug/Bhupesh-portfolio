import './globals.css'

export const metadata = {
  title: 'Bhupesh Chandra Dimri — Financial Analyst',
  description: 'Financial Analyst specializing in FP&A, financial modeling, and data-driven decision-making.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      {/* suppressHydrationWarning prevents false hydration mismatches caused by
          browser extensions (e.g. hix, Grammarly) injecting attributes into <body>
          at runtime — this is not a code bug, it's an extension side-effect */}
      <body suppressHydrationWarning>{children}</body>
    </html>
  )
}
