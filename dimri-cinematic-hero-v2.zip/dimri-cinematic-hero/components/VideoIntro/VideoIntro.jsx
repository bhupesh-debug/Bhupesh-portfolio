'use client'

import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import CinematicLayer from '../CinematicLayer/CinematicLayer'
import styles from './VideoIntro.module.css'

const PlayIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M8 5v14l11-7z" />
  </svg>
)

const PauseIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M6 5h4v14H6zM14 5h4v14h-4z" />
  </svg>
)

const SoundOnIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M3 10v4h4l5 5V5L7 10H3z" />
    <path d="M16.5 12c0-1.77-1-3.29-2.5-4.03v8.05c1.5-.74 2.5-2.26 2.5-4.02z" />
    <path d="M14 4.45v2.06c2.89.86 5 3.54 5 6.49s-2.11 5.63-5 6.49v2.06c4.01-.91 7-4.49 7-8.55s-2.99-7.64-7-8.55z" />
  </svg>
)

const SoundOffIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M16.5 12c0-1.77-1-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63z" />
    <path d="M19 12c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71z" />
    <path d="M4.27 3 3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4 9.91 6.09 12 8.18V4z" />
  </svg>
)

export default function VideoIntro({
  videoSrc,
  resumeSrc,
  firstName,
  lastName,
  roleSubtitle,
  tagline,
  highlights = [],
}) {
  const rootRef = useRef(null)
  const fgVideoRef = useRef(null)
  const bgVideoRef = useRef(null)

  const [isPlaying, setIsPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(true)
  const [showSoundHint, setShowSoundHint] = useState(true)

  // GSAP entrance sequence
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } })
      tl.from(`.${styles.tagline}`, { opacity: 0, y: 20, duration: 0.8 })
        .from(
          `.${styles.nameLine}`,
          { opacity: 0, y: 60, duration: 1.2, stagger: 0.15 },
          '-=0.4'
        )
        .from(`.${styles.subtitle}`, { opacity: 0, y: 20, duration: 0.8 }, '-=0.6')
        .from(`.${styles.actions}`, { opacity: 0, y: 16, duration: 0.9 }, '-=0.5')
        .from(`.${styles.controls}`, { opacity: 0, duration: 1 }, '-=0.5')
        .from(`.${styles.scrollIndicator}`, { opacity: 0, duration: 1 }, '-=0.4')
    }, rootRef)

    return () => ctx.revert()
  }, [])

  // Auto-hide the "tap for sound" hint after 5s
  useEffect(() => {
    const timer = setTimeout(() => setShowSoundHint(false), 5000)
    return () => clearTimeout(timer)
  }, [])

  const togglePlay = () => {
    const fg = fgVideoRef.current
    const bg = bgVideoRef.current
    if (!fg || !bg) return
    if (isPlaying) {
      fg.pause()
      bg.pause()
    } else {
      fg.play()
      bg.play()
    }
    setIsPlaying(!isPlaying)
  }

  const toggleMute = () => {
    const fg = fgVideoRef.current
    if (!fg) return
    fg.muted = !fg.muted
    setIsMuted(fg.muted)
    setShowSoundHint(false)
  }

  const scrollToNext = () => {
    document.getElementById('next-section')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div className={styles.root} ref={rootRef}>
      {/* Blurred ambient background layer */}
      <video
        ref={bgVideoRef}
        className={styles.bgVideo}
        src={videoSrc}
        autoPlay
        muted
        loop
        playsInline
        aria-hidden="true"
      />

      {/* Crisp foreground video */}
      <video
        ref={fgVideoRef}
        className={styles.fgVideo}
        src={videoSrc}
        autoPlay
        muted
        loop
        playsInline
      />

      {/* Cinematic gradient overlays */}
      <div className={styles.gradientBottom} />
      <div className={styles.vignette} />

      {/* Three.js bokeh particle layer */}
      <CinematicLayer />

      {/* Content */}
      <div className={styles.content}>
        <span className={styles.tagline}>{tagline}</span>

        <h1 className={styles.name}>
          <span className={styles.nameLine}>{firstName}</span>
          <span className={styles.nameLine}>{lastName}</span>
        </h1>

        <p className={styles.subtitle}>{roleSubtitle}</p>

        <div className={styles.actions}>
          <a
            href={resumeSrc}
            download
            className={styles.resumeButton}
          >
            Download Résumé
          </a>

          {highlights.length > 0 && (
            <div className={styles.highlights}>
              {highlights.map((h) => (
                <div className={styles.highlightStat} key={h.label}>
                  <span className={styles.highlightValue}>{h.value}</span>
                  <span className={styles.highlightLabel}>{h.label}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className={styles.controls}>
        <button
          className={styles.controlButton}
          onClick={togglePlay}
          aria-label={isPlaying ? 'Pause video' : 'Play video'}
        >
          {isPlaying ? <PauseIcon /> : <PlayIcon />}
        </button>
        <button
          className={styles.controlButton}
          onClick={toggleMute}
          aria-label={isMuted ? 'Unmute video' : 'Mute video'}
        >
          {isMuted ? <SoundOffIcon /> : <SoundOnIcon />}
        </button>

        {showSoundHint && (
          <span className={styles.soundHint}>Tap for sound</span>
        )}
      </div>

      {/* Scroll indicator */}
      <button
        className={styles.scrollIndicator}
        onClick={scrollToNext}
        aria-label="Scroll to next section"
      >
        <span className={styles.scrollLine} />
      </button>
    </div>
  )
}
