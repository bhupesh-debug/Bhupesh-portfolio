'use client'

import { useEffect, useRef } from 'react'
import * as THREE from 'three'

const DESKTOP_PARTICLE_COUNT = 50
const MOBILE_PARTICLE_COUNT = 18
const MOBILE_BREAKPOINT = 768

// Warm orange + soft white palette, ~70/30 split
const WARM_COLORS = [0xff9d4d, 0xffb877, 0xffa866, 0xff8c3d]
const SOFT_COLORS = [0xfff5e8, 0xffe9d6]

function makeParticleTexture() {
  const size = 128
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext('2d')
  const gradient = ctx.createRadialGradient(
    size / 2,
    size / 2,
    0,
    size / 2,
    size / 2,
    size / 2
  )
  gradient.addColorStop(0, 'rgba(255,255,255,1)')
  gradient.addColorStop(0.4, 'rgba(255,255,255,0.6)')
  gradient.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, size, size)
  const texture = new THREE.CanvasTexture(canvas)
  return texture
}

export default function CinematicLayer() {
  const canvasRef = useRef(null)
  const mouseRef = useRef({ x: 0, y: 0 })
  const rafRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const isMobile = window.innerWidth < MOBILE_BREAKPOINT
    const particleCount = isMobile ? MOBILE_PARTICLE_COUNT : DESKTOP_PARTICLE_COUNT

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(
      55,
      window.innerWidth / window.innerHeight,
      0.1,
      100
    )
    camera.position.z = 12

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
    })
    renderer.setClearColor(0x000000, 0)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.setSize(window.innerWidth, window.innerHeight)

    // --- Particle geometry ---
    const positions = new Float32Array(particleCount * 3)
    const sizes = new Float32Array(particleCount)
    const colors = new Float32Array(particleCount * 3)
    const basePositions = []
    const phases = []
    const speeds = []
    const amplitudes = []

    const color = new THREE.Color()

    for (let i = 0; i < particleCount; i++) {
      const x = (Math.random() - 0.5) * 16
      const y = (Math.random() - 0.5) * 10
      const z = (Math.random() - 0.5) * 10

      positions[i * 3] = x
      positions[i * 3 + 1] = y
      positions[i * 3 + 2] = z

      basePositions.push({ x, y, z })
      phases.push(Math.random() * Math.PI * 2)
      speeds.push(0.15 + Math.random() * 0.25)
      amplitudes.push(0.4 + Math.random() * 0.8)

      const isWarm = Math.random() < 0.7
      const palette = isWarm ? WARM_COLORS : SOFT_COLORS
      color.set(palette[Math.floor(Math.random() * palette.length)])
      colors[i * 3] = color.r
      colors[i * 3 + 1] = color.g
      colors[i * 3 + 2] = color.b

      // Bigger = feels closer/brighter, smaller = recedes into the depth
      sizes[i] = 0.4 + Math.random() * 1.4
    }

    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1))

    const sprite = makeParticleTexture()

    const material = new THREE.PointsMaterial({
      size: 0.6,
      map: sprite,
      vertexColors: true,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
    })

    const points = new THREE.Points(geometry, material)
    scene.add(points)

    // --- Mouse parallax ---
    const handleMouseMove = (e) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1
    }
    window.addEventListener('mousemove', handleMouseMove)

    // --- Resize ---
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', handleResize)

    // --- Animation loop ---
    const clock = new THREE.Clock()

    const animate = () => {
      const t = clock.getElapsedTime()
      const posAttr = geometry.attributes.position

      for (let i = 0; i < particleCount; i++) {
        const base = basePositions[i]
        const phase = phases[i]
        const speed = speeds[i]
        const amp = amplitudes[i]

        posAttr.array[i * 3] = base.x + Math.sin(t * speed + phase) * amp * 0.5
        posAttr.array[i * 3 + 1] =
          base.y + Math.sin(t * speed * 0.8 + phase) * amp
        posAttr.array[i * 3 + 2] =
          base.z + Math.cos(t * speed * 0.6 + phase) * amp * 0.5
      }
      posAttr.needsUpdate = true

      // Damped camera parallax — lerp toward target, never snap
      const targetX = mouseRef.current.x * 0.8
      const targetY = mouseRef.current.y * 0.5
      camera.position.x += (targetX - camera.position.x) * 0.05
      camera.position.y += (targetY - camera.position.y) * 0.05
      camera.lookAt(0, 0, 0)

      renderer.render(scene, camera)
      rafRef.current = requestAnimationFrame(animate)
    }
    animate()

    return () => {
      cancelAnimationFrame(rafRef.current)
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('resize', handleResize)
      geometry.dispose()
      material.dispose()
      sprite.dispose()
      renderer.dispose()
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: 2,
      }}
    />
  )
}
