'use client'

import { useEffect, useRef } from 'react'
import styles from './ProfileSection.module.css'

const LinkedInIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
  </svg>
)

const experiences = [
  {
    company: 'JPMorgan Chase & Co.',
    role: 'Financial Analyst',
    period: 'Jul 2025 — Present',
    location: 'New York, USA',
    highlights: [
      'Improved forecast accuracy by 27% via SQL-driven pipelines + Python predictive models',
      'Reduced reporting latency from 48 hours to under 2 hours with real-time Power BI dashboards',
      'Reduced controllable expenses by 16% through granular variance analysis frameworks',
      'Achieved 99.5% reporting accuracy by automating financial workflows with Python & Excel',
    ],
  },
  {
    company: 'Virtual Infotech',
    role: 'Financial Planning & Analysis',
    period: 'Mar 2021 — Dec 2024',
    location: 'India',
    highlights: [
      'Managed $50M+ annual budgets with 24% improvement in forecast reliability',
      'Improved strategic decision-making speed by 30% via sensitivity-driven scenario frameworks',
      'Reduced operational costs by 18% through deep-dive cost structure analysis',
      'Cut manual reporting workload by 50% using SQL and Excel VBA automation',
    ],
  },
  {
    company: 'Green Touch Technology',
    role: 'Financial Planning Analyst',
    period: 'Jun 2019 — Feb 2021',
    location: 'India',
    highlights: [
      'Increased capital efficiency by 19% via robust cash flow and capex modeling',
      'Reduced reporting cycle time by 35% with dynamic KPI dashboards',
      'Saved 13% in staffing costs through headcount and capacity planning models',
      'Cut manual data preparation time by 40% using Power Query transformations',
    ],
  },
  {
    company: 'Infinite Infolab',
    role: 'Financial Analyst — Operations Finance',
    period: 'Aug 2016 — May 2019',
    location: 'India',
    highlights: [
      'Reduced operational costs by 11% through large-scale financial data analysis',
      'Cut manual reporting effort by 45% with automated Excel VBA solutions',
      'Improved planning accuracy by 17% with detailed financial projections and variance reports',
      'Zero major audit observations — zero — via IFRS and GAAS compliance readiness',
    ],
  },
]

const skills = {
  'Financial Planning & Analysis': ['Budgeting', 'Forecasting', 'Variance Analysis', 'P&L Management', 'Cash Flow Modeling', 'Scenario Analysis'],
  'Data & Programming': ['SQL', 'Python (Pandas, NumPy, Scikit-learn)', 'Excel VBA', 'Power Query', 'Automation Scripting'],
  'BI & Visualization': ['Power BI', 'Tableau', 'Dashboard Development', 'KPI Reporting'],
  'ERP & Systems': ['Oracle Fusion ERP/EPM', 'SAP', 'NetSuite', 'Bloomberg Terminal', 'FactSet', 'Capital IQ'],
  'Compliance': ['US GAAP', 'IFRS', 'SOX 404', 'COSO Framework', 'GAAS', 'PCAOB Standards'],
}

const education = [
  {
    degree: 'M.S. Accounting Analytics & Data Technology',
    school: 'Pace University, Lubin School of Business',
    year: 'Dec 2025',
  },
  {
    degree: 'MBA, Finance & Accounting',
    school: 'Sikkim Manipal University',
    year: '2015',
  },
  {
    degree: 'Bachelor of Commerce',
    school: 'HNB Garhwal University',
    year: '2010',
  },
]

export default function ProfileSection() {
  const sectionRef = useRef(null)

  // Intersection Observer for staggered fade-in on scroll
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add(styles.visible)
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.12 }
    )

    const targets = sectionRef.current?.querySelectorAll(`.${styles.fadeUp}`)
    targets?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section id="next-section" className={styles.root} ref={sectionRef}>
      {/* Subtle warm top border glow matching the hero */}
      <div className={styles.topGlow} />

      <div className={styles.container}>

        {/* ── Identity header ── */}
        <div className={`${styles.identity} ${styles.fadeUp}`}>
          <div className={styles.identityText}>
            <h2 className={styles.sectionName}>Bhupesh Chandra Dimri</h2>
            <p className={styles.sectionRole}>Financial Analyst — FP&amp;A &amp; Financial Modeling</p>
            <p className={styles.sectionSummary}>
              9+ years in banking and financial services. I turn complex data
              into dashboards that executives actually use, forecasts that hold
              up under scrutiny, and cost models that find the leakage others
              miss.
            </p>
          </div>
          <a
            href="https://www.linkedin.com/in/bhupeshdimri/"
            target="_blank"
            rel="noopener noreferrer"
            className={styles.linkedinButton}
          >
            <LinkedInIcon />
            Connect on LinkedIn
          </a>
        </div>

        {/* ── Stats bar ── */}
        <div className={`${styles.statsRow} ${styles.fadeUp}`}>
          {[
            { value: '9+', label: 'Years Experience' },
            { value: '27%', label: 'Forecast Accuracy ↑' },
            { value: '<2hrs', label: 'Reporting Latency' },
            { value: '$50M+', label: 'Budgets Managed' },
            { value: '99.5%', label: 'Reporting Accuracy' },
          ].map((s) => (
            <div className={styles.statCard} key={s.label}>
              <span className={styles.statValue}>{s.value}</span>
              <span className={styles.statLabel}>{s.label}</span>
            </div>
          ))}
        </div>

        {/* ── Experience ── */}
        <div className={`${styles.block} ${styles.fadeUp}`}>
          <h3 className={styles.blockTitle}>Experience</h3>
          <div className={styles.timeline}>
            {experiences.map((exp, i) => (
              <div className={styles.timelineItem} key={i}>
                <div className={styles.timelineDot} />
                <div className={styles.timelineContent}>
                  <div className={styles.expHeader}>
                    <span className={styles.expCompany}>{exp.company}</span>
                    <span className={styles.expPeriod}>{exp.period}</span>
                  </div>
                  <p className={styles.expRole}>{exp.role} · {exp.location}</p>
                  <ul className={styles.expList}>
                    {exp.highlights.map((h, j) => (
                      <li key={j}>{h}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Skills ── */}
        <div className={`${styles.block} ${styles.fadeUp}`}>
          <h3 className={styles.blockTitle}>Skills</h3>
          <div className={styles.skillsGrid}>
            {Object.entries(skills).map(([category, items]) => (
              <div className={styles.skillGroup} key={category}>
                <h4 className={styles.skillCategory}>{category}</h4>
                <div className={styles.skillTags}>
                  {items.map((skill) => (
                    <span className={styles.skillTag} key={skill}>{skill}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Education ── */}
        <div className={`${styles.block} ${styles.fadeUp}`}>
          <h3 className={styles.blockTitle}>Education</h3>
          <div className={styles.eduGrid}>
            {education.map((edu, i) => (
              <div className={styles.eduCard} key={i}>
                <span className={styles.eduYear}>{edu.year}</span>
                <p className={styles.eduDegree}>{edu.degree}</p>
                <p className={styles.eduSchool}>{edu.school}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── Footer CTA ── */}
        <div className={`${styles.footerCta} ${styles.fadeUp}`}>
          <p className={styles.footerText}>Open to Financial Analyst, FP&A, and Data Analytics roles.</p>
          <div className={styles.footerLinks}>
            <a
              href="https://www.linkedin.com/in/bhupeshdimri/"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.footerLinkedIn}
            >
              <LinkedInIcon />
              LinkedIn Profile
            </a>
            <a
              href="/resume/dimri-resume.pdf"
              download
              className={styles.footerResume}
            >
              Download Résumé
            </a>
          </div>
        </div>

      </div>
    </section>
  )
}
